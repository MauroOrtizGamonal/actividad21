#Diseña un algoritmo que permita mostrar las tablas de multiplicar del 1 al 10

def multiplicar():
    for n in range(11):
        for j in range(11):
            print(f'{j} * {n} = {j*n}')
multiplicar()
